//$.sessionTimeout({ keepAliveUrl: "pages-starter.html", logoutButton: "Logout", logoutUrl: "auth-login.html", redirUrl: "auth-lock-screen.html", warnAfter: 3e3, redirAfter: 3e4, countdownMessage: "Redirecting in {timer} seconds." });


$.sessionTimeout({ keepAliveUrl: "/", logoutButton: "Logout", logoutUrl: "AuthLogin", redirUrl: "/", warnAfter: 3e3, redirAfter: 3e4, countdownMessage: "Redirecting in {timer} seconds." });

